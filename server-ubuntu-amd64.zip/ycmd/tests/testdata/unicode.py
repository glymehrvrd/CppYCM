def Foo():
  """aafäö"""
  pass

Fo
