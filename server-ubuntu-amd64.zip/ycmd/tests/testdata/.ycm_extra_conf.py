def FlagsForFile( filename ):
  return {
    'flags': ['-x', 'c++', '-I', '.'],
    'do_cache': True
  }
