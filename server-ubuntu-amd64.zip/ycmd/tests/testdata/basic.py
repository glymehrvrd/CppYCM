class Foo(object):
  def __init__(self):
    self.a = 1
    self.b = 2

f = Foo()
f.
