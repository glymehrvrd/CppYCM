using System;

namespace testy
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			int 九 = 9;
			Console.
		}
	}
}
